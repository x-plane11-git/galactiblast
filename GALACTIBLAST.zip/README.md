# galactiblast

Galactiblast is a space invaders inspired video game
built in python.

Upcoming features include:
- Score counter
1:26:51

